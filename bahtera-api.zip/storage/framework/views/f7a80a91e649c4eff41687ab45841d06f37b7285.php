<?php $orderQuery = app('App\Models\Orders\OrderQuery'); ?>

<table class="receipt-table full-bordered" style="width: 100%">
    <thead>
        <tr>
            <td align="center">NO</td>
            <td align="center">KODE BARANG</td>
            <td align="center">NAMA ITEM</td>
            <td align="center">SATUAN</td>
            <td align="center">QTY</td>
            <td align="center">KETERANGAN</td>
        </tr>
    </thead>
    <tbody>
        <?php
            $rowCount = 1
        ?>
        <?php $__currentLoopData = $orderQuery->getProductDetail($order->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td align="center"><?php echo e($rowCount); ?></td>
            <td align="center"><?php echo e($row->product->sku); ?></td>
            <td align="center"><?php echo e($row->product->name); ?></td>
            <td align="center"><?php echo e($row->unit); ?></td>
            <td align="center"><?php echo e($row->quantity_order); ?></td>
            <td><?php echo e($row->notes); ?></td>
        </tr>
        <?php
            $rowCount += 1
        ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if($rowCount < 26): ?>
            <?php
            for ($i=1; $i < 26-$rowCount; $i++) {
                echo "<tr>";
                echo "<td></td>";
                echo "<td></td>";
                echo "<td></td>";
                echo "<td></td>";
                echo "<td></td>";
                echo "<td></td>";
                echo "</tr>";
            }
             ?>
        <?php endif; ?>
    </tbody>

</table>
<?php /**PATH C:\laragon\www\bahtera-mart\bahtera-api\resources\views/order/list.blade.php ENDPATH**/ ?>