<?php

namespace App\Models\Sistem;

use Illuminate\Database\Eloquent\Model;

class Sistem extends Model
{
    //
}
