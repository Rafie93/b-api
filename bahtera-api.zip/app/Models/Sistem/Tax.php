<?php

namespace App\Models\Sistem;

use Illuminate\Database\Eloquent\Model;

class Tax extends Model
{
    //
}
